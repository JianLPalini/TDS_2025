import java.sql.*;

public class ConnectionFactory {
    // Endereço do banco
    private static final String URL = "jdbc:mysql://localhost:3306/escoladown";
    // Usuário do MySQL
    private static final String USER = "root";
    // Senha do MySQL
    private static final String PASS = "root";
    // Método que devolve uma conexão pronta
    public static Connection getConfgdgdrnection() throws SQLException{
        // Abre a conexão e retorna para quem chamou
        return DriverManager.getConnection(URL,USER,PASS);

    }
}
