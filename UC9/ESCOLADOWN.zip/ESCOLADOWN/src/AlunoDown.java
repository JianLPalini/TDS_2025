import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AlunoDown {
    // CREATE: inserir o aluno no banco
    public void cadastrar(Aluno aluno){
        // SQL com ? (parâmetro) para evitar SQL injection
        String sql = "INSERT INTO alunos (nome) VALUES (?)";
        // Tratamento de possíveis erros | no caso fecha automaticamente a conexão e o statement
        try(Connection conn = ConnectionFactory.getConnection();PreparedStatement stmt = conn.prepareStatement(sql)){
            // Troca o ? pelo nome do aluno
            stmt.setString(1, aluno.getNome());
            // Executa o INSERT (podemos utilizar o executeUpdate para INSERT/UPDATE/DELETE)
            stmt.executeUpdate();
        } catch (Exception e){
            // Se der erro, mostramos uma mensagem clara
            throw new RuntimeException("Erro ao cadastrar aluno", e);
        }
    }
    // READ: listar todos
    public List<Aluno>listar(){
        // SQL para buscar todos
        String sql = "SELECT id, nome FROM alunos";

        // Lista que vamos devolver preenchida
        List<Aluno> alunos = new ArrayList<>();
        try(Connection conn = ConnectionFactory.getConnection();
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery()){
                // Enquanto tiver linha no resultado
            while(rs.next()){
                int id = rs.getInt("id");
                String nome = rs.getString("nome");

                // Monta um objeto Aluno com os dados
                Aluno aluno = new Aluno(id,nome);

                //Adicionar na lista
                alunos.add(aluno);
            }

        } catch (Exception e) {
            throw new RuntimeException("Erro ao listar alunos", e);
        }
            // Devolver a lista pronta
        return alunos;
    }

}
