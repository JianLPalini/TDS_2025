import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Scanner = entrada de dados (nosso prompt pro java)
        Scanner scanner = new Scanner(System.in);

        // DAO = quem conversa com o banco
        AlunoDown down = new AlunoDown();

        System.out.println("Quantos alunos deseja cadastrar? ");
        int quantidade = scanner.nextInt();
        scanner.nextLine();  // Limpar o buffer de leitura

        // Loop para cadastrar alunos
        for (int i = 1; i <= quantidade; i++) {
            System.out.println("Digite o nome do aluno " + i + " :");
            String nome = scanner.nextLine();
            // Cria o aluno (Model)
            Aluno aluno = new Aluno(nome);

            // Envia para o DAO salvar no banco
            down.cadastrar(aluno);
        }

        // Lista os alunos cadastrados
        System.out.println("\n=== ALUNOS CADASTRADOS ===");
        down.listar().forEach(aluno -> {
            System.out.println(aluno.getId() + " - " + aluno.getNome());
        });

        scanner.close();
    }
}
