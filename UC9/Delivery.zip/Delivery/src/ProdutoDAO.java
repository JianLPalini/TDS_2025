public class ProdutoDAO {
    //CREATE: inserir o aluno no banco
    public void cadastrar(Produto produto){
        //SQL com ? (parâmetro) para evitar SQL injection
        String sql = "INSERT INTO produto (nome)"
    }
}
